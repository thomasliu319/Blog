package com.roncoo.eshop.inventory.mapper;

import com.roncoo.eshop.inventory.model.User;

public interface UserMapper {

	public User findUserInfo();
	
}
